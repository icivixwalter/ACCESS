MSys_QUERY_Qry01_01_SELECT_TUTTE_CurrentProject
     Note
            Questa query estrae le query attinenti al progetto corrente
            
        struttura

            SELECT MSys_TABELLE.*, 


                            @AGGIORNAMENTO_CODICE---->2022.10.049@Query_CurrentProject
                            @ESTRAI.QUERY.PROGETTO.CORRENTE
                            @QUERY@PROGETTO@CORRENTE