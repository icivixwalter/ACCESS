@README.md




	Parametri
		I parametri relativi alla path per tutto il progetto sono questi:
			path:
				c:\GESTIONI\GESTIONE_LLPP\25_GESTIONE_LLPP\LLPP_ARCHIVI_MDB\MSYS_OGGETTI\
				c:\GESTIONI\GESTIONE_LLPP\25_GESTIONE_LLPP\LLPP_ARCHIVI_MDB\MSYS_OGGETTI\SALVATAGGI\



